﻿using System;

namespace JUDO
{
    public class Participant
    {
        public int ParticipantID { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string GenderText => Gender == "m" ? "М" : "Ж";
        public DateTime BirthDate { get; set; }
        public decimal? Weight { get; set; }
        public string Location { get; set; }
        public string ClubName { get; set; }
    }

    public class GroupItem
    {
        public int GroupID { get; set; }
        public string AgeCategory { get; set; }
        public string WeightCategory { get; set; }
        public string Gender { get; set; }          // "m" или "f"
        public string GenderText => Gender == "m" ? "М" : "Ж";
        public int? TatamiNumber { get; set; }
        public string Status { get; set; }
        public int ParticipantCount { get; set; }   // Количество участников в группе
    }

    public class MatchItem
    {
        public int MatchID { get; set; }
        public string GroupName { get; set; }
        public string ParticipantWhite { get; set; }
        public string ParticipantRed { get; set; }
        public int? TatamiNumber { get; set; }
        public string Status { get; set; }
    }
}