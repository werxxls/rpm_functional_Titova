﻿using System.Windows;

namespace JUDO
{
    public partial class NavigationWindow : Window
    {
        public NavigationWindow()
        {
            InitializeComponent();
        }

        private void ButtonRegistrationParticipant_Click(object sender, RoutedEventArgs e)
        {
            new RegistrationWindow().Show();
        }

        private void ButtonGroup_Click(object sender, RoutedEventArgs e)
        {
            new GroupWindow().Show();
        }

        private void ButtonMeeting_Click(object sender, RoutedEventArgs e)
        {
            new MeetingWindow().Show();
        }

        private void ButtonCompetitions_Click(object sender, RoutedEventArgs e)
        {
            new CompetitionsWindow().Show();
        }

        private void ButtonManagmentCompetitions_Click(object sender, RoutedEventArgs e)
        {
            new ManagmentWindow().Show();
        }

        private void ButtonDiplom_Click(object sender, RoutedEventArgs e)
        {
            new DiplomWindow().Show();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }     
    }
}