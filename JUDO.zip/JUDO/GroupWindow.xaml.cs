﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace JUDO
{
    public partial class GroupWindow : Window
    {
        private readonly string _conn = ConfigurationManager.ConnectionStrings["JUDODbConn"].ConnectionString;
        private readonly List<GroupItem> _groups = new List<GroupItem>();
        private readonly DateTime _competitionDate = new DateTime(2017, 12, 22);

        public GroupWindow()
        {
            InitializeComponent();
            Loaded += GroupWindow_Loaded;
        }

        private void GroupWindow_Loaded(object sender, RoutedEventArgs e) => LoadGroups();

        private void LoadGroups(string search = "", string sort = "", bool showSingleParticipantOnly = false)
        {
            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    string sql = @"
                        SELECT 
                            cg.GroupID,
                            ac.CategoryName AS AgeCategory,
                            wc.CategoryName AS WeightCategory,
                            cg.Gender,
                            t.TatamiNumber,
                            cg.GroupStatus,
                            (SELECT COUNT(*) FROM Participants p WHERE p.GroupID = cg.GroupID AND p.IsDisqualified = 0) AS ParticipantCount
                        FROM CompetitionGroups cg
                        JOIN AgeCategories ac ON cg.AgeCatID = ac.AgeCatID
                        JOIN WeightCategories wc ON cg.WeightCatID = wc.WeightCatID
                        LEFT JOIN Tatami t ON cg.TatamiID = t.TatamiID
                        WHERE cg.GroupStatus = 'Active'";

                    if (!string.IsNullOrEmpty(search))
                        sql += " AND (ac.CategoryName LIKE @S OR wc.CategoryName LIKE @S)";

                    if (showSingleParticipantOnly)
                        sql += " AND (SELECT COUNT(*) FROM Participants p WHERE p.GroupID = cg.GroupID AND p.IsDisqualified = 0) = 1";

                    if (!string.IsNullOrEmpty(sort))
                        sql += $" ORDER BY {sort}";
                    else
                        sql += " ORDER BY ac.AgeCatID ASC, wc.WeightCatID ASC, cg.Gender ASC, cg.GroupID ASC";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        if (!string.IsNullOrEmpty(search))
                            cmd.Parameters.AddWithValue("@S", $"%{search}%");

                        using (var reader = cmd.ExecuteReader())
                        {
                            _groups.Clear();
                            while (reader.Read())
                            {
                                int? tat = reader.IsDBNull(4) ? (int?)null : reader.GetInt32(4);
                                _groups.Add(new GroupItem
                                {
                                    GroupID = reader.GetInt32(0),
                                    AgeCategory = reader.GetString(1),
                                    WeightCategory = reader.GetString(2),
                                    Gender = reader.GetString(3),
                                    TatamiNumber = tat,
                                    Status = reader.IsDBNull(5) ? "" : reader.GetString(5),
                                    ParticipantCount = reader.IsDBNull(6) ? 0 : reader.GetInt32(6)
                                });
                            }
                        }
                    }
                }
                GroupsDataGrid.ItemsSource = null;
                GroupsDataGrid.ItemsSource = _groups;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ButtonSearchSort_Click(object sender, RoutedEventArgs e)
        {
            string search = SearchTextBox.Text.Trim();
            if (search == "Поиск...") search = "";
            string sort = (SortComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "";
            LoadGroups(search, sort, false);
        }

        private void ButtonSearch_Click(object sender, RoutedEventArgs e) => ButtonSearchSort_Click(sender, e);

        private void ButtonRefresh_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Text = "Поиск...";
            if (SortComboBox.Items.Count > 0)
                SortComboBox.SelectedIndex = 0;
            LoadGroups();
        }

        private void ButtonShowSingleParticipantGroups_Click(object sender, RoutedEventArgs e)
        {
            LoadGroups("", "", true);
            MessageBox.Show($"Найдено групп с 1 участником: {_groups.Count}", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SearchTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (((TextBox)sender).Text == "Поиск...")
                ((TextBox)sender).Text = "";
        }

        private void SearchTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(((TextBox)sender).Text))
                ((TextBox)sender).Text = "Поиск...";
        }

        private void ButtonGenerate_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Сформировать группы?\n\nВСЕ СТАРЫЕ ДАННЫЕ БУДУТ УДАЛЕНЫ",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                ClearOldGroups();
                GenerateGroups();
                LoadGroups();
                MessageBox.Show($"Группы сформированы! Всего групп: {_groups.Count}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearOldGroups()
        {
            using (var conn = new SqlConnection(_conn))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                    try
                    {
                        using (var cmd = new SqlCommand("UPDATE Participants SET GroupID = NULL", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DELETE FROM MatchParticipants", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DELETE FROM Matches", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DELETE FROM CompetitionGroups", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DELETE FROM AgeCategories", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DELETE FROM WeightCategories", conn, tr)) cmd.ExecuteNonQuery();

                        using (var cmd = new SqlCommand("DBCC CHECKIDENT ('Matches', RESEED, 0)", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DBCC CHECKIDENT ('MatchParticipants', RESEED, 0)", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DBCC CHECKIDENT ('CompetitionGroups', RESEED, 0)", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DBCC CHECKIDENT ('AgeCategories', RESEED, 0)", conn, tr)) cmd.ExecuteNonQuery();
                        using (var cmd = new SqlCommand("DBCC CHECKIDENT ('WeightCategories', RESEED, 0)", conn, tr)) cmd.ExecuteNonQuery();

                        tr.Commit();
                    }
                    catch { tr.Rollback(); throw; }
                }
            }
        }

        private void GenerateGroups()
        {
            using (var conn = new SqlConnection(_conn))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                    try
                    {
                        var tatamiList = GetOrCreateTatamiList(conn, tr);
                        var participants = GetEligibleParticipants(conn, tr);
                        if (participants.Count == 0) { tr.Commit(); return; }

                        var grouped = participants.GroupBy(p => new
                        {
                            AgeCatID = GetOrCreateAgeCategoryID(conn, tr, p.BirthDate),
                            WeightCatID = GetOrCreateWeightCategoryID(conn, tr, p.Weight, p.Gender),
                            p.Gender
                        });

                        int tatamiIndex = 0;
                        int categoryCounter = 0;

                        foreach (var g in grouped)
                        {
                            var list = g.ToList();
                            const int MAX_PARTICIPANTS_PER_GROUP = 8;
                            int subGroupSize = list.Count > MAX_PARTICIPANTS_PER_GROUP ? 5 : list.Count;

                            for (int i = 0; i < list.Count; i += subGroupSize)
                            {
                                var chunk = list.Skip(i).Take(subGroupSize).ToList();
                                if (chunk.Count == 0) continue;

                                categoryCounter++;
                                int uniqueAgeCatID = CreateUniqueAgeCategory(conn, tr, categoryCounter);

                                int newGroupID = CreateCompetitionGroup(conn, tr,
                                    uniqueAgeCatID, g.Key.WeightCatID, g.Key.Gender,
                                    tatamiList[tatamiIndex % tatamiList.Count]);

                                foreach (var p in chunk)
                                    UpdateParticipantGroup(conn, tr, p.ParticipantID, newGroupID);

                                CreateMatchesForGroup(conn, tr, newGroupID, chunk, tatamiList[tatamiIndex % tatamiList.Count]);

                                tatamiIndex++;
                            }
                        }
                        tr.Commit();
                    }
                    catch { tr.Rollback(); throw; }
                }
            }
        }

        private void CreateMatchesForGroup(SqlConnection conn, SqlTransaction tr, int groupID, List<Participant> participants, int tatamiID)
        {
            if (participants.Count < 2) return;

            var allPairs = new List<(Participant p1, Participant p2)>();
            for (int i = 0; i < participants.Count; i++)
            {
                for (int j = i + 1; j < participants.Count; j++)
                {
                    allPairs.Add((participants[i], participants[j]));
                }
            }

            var orderedPairs = new List<(Participant p1, Participant p2)>();
            var used = new bool[allPairs.Count];

            if (allPairs.Count > 0)
            {
                orderedPairs.Add(allPairs[0]);
                used[0] = true;
            }

            while (orderedPairs.Count < allPairs.Count)
            {
                var last = orderedPairs[orderedPairs.Count - 1];
                int bestIdx = -1;
                int bestScore = -1;

                for (int i = 0; i < allPairs.Count; i++)
                {
                    if (used[i]) continue;

                    var pair = allPairs[i];
                    int score = 0;
                    if (pair.p1.ParticipantID != last.p1.ParticipantID &&
                        pair.p1.ParticipantID != last.p2.ParticipantID &&
                        pair.p2.ParticipantID != last.p1.ParticipantID &&
                        pair.p2.ParticipantID != last.p2.ParticipantID)
                    {
                        score = 2;
                    }
                    else if (pair.p1.ParticipantID != last.p1.ParticipantID ||
                             pair.p2.ParticipantID != last.p2.ParticipantID)
                    {
                        score = 1;
                    }

                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestIdx = i;
                    }
                }

                if (bestIdx >= 0)
                {
                    orderedPairs.Add(allPairs[bestIdx]);
                    used[bestIdx] = true;
                }
                else
                {
                    for (int i = 0; i < allPairs.Count; i++)
                    {
                        if (!used[i])
                        {
                            orderedPairs.Add(allPairs[i]);
                            used[i] = true;
                            break;
                        }
                    }
                }
            }

            int sequenceNumber = 1;
            foreach (var pair in orderedPairs)
            {
                bool whiteFirst = sequenceNumber % 2 == 1;
                if (whiteFirst)
                    CreateMatch(conn, tr, groupID, pair.p1, pair.p2, sequenceNumber++, tatamiID);
                else
                    CreateMatch(conn, tr, groupID, pair.p2, pair.p1, sequenceNumber++, tatamiID);
            }
        }

        private void CreateMatch(SqlConnection conn, SqlTransaction tr, int groupID, Participant white, Participant red, int sequenceNumber, int tatamiID, bool isFinal = false)
        {
            int matchID;
            using (var cmd = new SqlCommand(
                "INSERT INTO Matches (GroupID, TatamiID, MatchStatus, SequenceNumber) OUTPUT INSERTED.MatchID VALUES (@GroupID, @TatamiID, 'Ожидается', @Seq)",
                conn, tr))
            {
                cmd.Parameters.AddWithValue("@GroupID", groupID);
                cmd.Parameters.AddWithValue("@TatamiID", tatamiID);
                cmd.Parameters.AddWithValue("@Seq", sequenceNumber);
                matchID = (int)cmd.ExecuteScalar();
            }

            using (var cmd = new SqlCommand(
                "INSERT INTO MatchParticipants (MatchID, ParticipantID, BeltColor) VALUES (@MatchID, @ParticipantID, @Belt)",
                conn, tr))
            {
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@MatchID", matchID);
                cmd.Parameters.AddWithValue("@ParticipantID", white.ParticipantID);
                cmd.Parameters.AddWithValue("@Belt", "W");
                cmd.ExecuteNonQuery();

                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@MatchID", matchID);
                cmd.Parameters.AddWithValue("@ParticipantID", red.ParticipantID);
                cmd.Parameters.AddWithValue("@Belt", "R");
                cmd.ExecuteNonQuery();
            }
        }

        private int CreateUniqueAgeCategory(SqlConnection conn, SqlTransaction tr, int categoryNumber)
        {
            string categoryName = $"Категория {categoryNumber}";

            using (var cmd = new SqlCommand("SELECT AgeCatID FROM AgeCategories WHERE CategoryName = @Name", conn, tr))
            {
                cmd.Parameters.AddWithValue("@Name", categoryName);
                var res = cmd.ExecuteScalar();
                if (res != null) return (int)res;
            }

            using (var cmd = new SqlCommand(
                "INSERT INTO AgeCategories (CategoryName, MinAge, MaxAge, MinBirthDate, MaxBirthDate) OUTPUT INSERTED.AgeCatID VALUES (@N, 0, 0, '1900-01-01', '2100-12-31')",
                conn, tr))
            {
                cmd.Parameters.AddWithValue("@N", categoryName);
                return (int)cmd.ExecuteScalar();
            }
        }

        private List<int> GetOrCreateTatamiList(SqlConnection conn, SqlTransaction tr)
        {
            var list = new List<int>();
            using (var cmd = new SqlCommand("SELECT TatamiID FROM Tatami ORDER BY TatamiNumber", conn, tr))
            using (var r = cmd.ExecuteReader()) { while (r.Read()) list.Add(r.GetInt32(0)); }
            if (list.Count == 0)
            {
                for (int i = 1; i <= 100; i++)
                {
                    int id;
                    using (var cmd = new SqlCommand("INSERT INTO Tatami (TatamiNumber) OUTPUT INSERTED.TatamiID VALUES (@N)", conn, tr))
                    {
                        cmd.Parameters.AddWithValue("@N", i);
                        id = (int)cmd.ExecuteScalar();
                    }
                    list.Add(id);
                }
            }
            return list;
        }

        private List<Participant> GetEligibleParticipants(SqlConnection conn, SqlTransaction tr)
        {
            var list = new List<Participant>();
            using (var cmd = new SqlCommand(
                "SELECT ParticipantID, Surname, Name, Gender, BirthDate, Weight FROM Participants WHERE IsDisqualified = 0 AND GroupID IS NULL",
                conn, tr))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    if (r.IsDBNull(5)) continue;
                    object weightObj = r.GetValue(5);
                    decimal weight = weightObj is decimal d ? d : Convert.ToDecimal(weightObj);

                    list.Add(new Participant
                    {
                        ParticipantID = r.GetInt32(0),
                        Surname = r.GetString(1),
                        Name = r.GetString(2),
                        Gender = r.GetString(3),
                        BirthDate = r.GetDateTime(4),
                        Weight = weight
                    });
                }
            }
            return list;
        }

        private int GetOrCreateAgeCategoryID(SqlConnection conn, SqlTransaction tr, DateTime birthDate)
        {
            int age = _competitionDate.Year - birthDate.Year;
            if (_competitionDate < birthDate.AddYears(age)) age--;

            int categoryNum = age - 5;
            if (categoryNum < 1) categoryNum = 1;
            if (categoryNum > 7) categoryNum = 7;

            string categoryName = $"Категория {categoryNum}";

            using (var cmd = new SqlCommand("SELECT AgeCatID FROM AgeCategories WHERE CategoryName = @Name", conn, tr))
            {
                cmd.Parameters.AddWithValue("@Name", categoryName);
                var res = cmd.ExecuteScalar();
                if (res != null) return (int)res;
            }

            DateTime maxBirth = _competitionDate.AddYears(-age);
            DateTime minBirth = maxBirth.AddDays(1);

            using (var cmd = new SqlCommand(
                "INSERT INTO AgeCategories (CategoryName, MinAge, MaxAge, MinBirthDate, MaxBirthDate) OUTPUT INSERTED.AgeCatID VALUES (@N, @MinA, @MaxA, @MinB, @MaxB)",
                conn, tr))
            {
                cmd.Parameters.AddWithValue("@N", categoryName);
                cmd.Parameters.AddWithValue("@MinA", age);
                cmd.Parameters.AddWithValue("@MaxA", age);
                cmd.Parameters.AddWithValue("@MinB", minBirth);
                cmd.Parameters.AddWithValue("@MaxB", maxBirth);
                return (int)cmd.ExecuteScalar();
            }
        }

        private int GetOrCreateWeightCategoryID(SqlConnection conn, SqlTransaction tr, decimal? weight, string gender)
        {
            if (!weight.HasValue) throw new InvalidOperationException("Нет веса");
            decimal w = Math.Round(weight.Value, 1);
            decimal minWeight, maxWeight;
            string categoryName;

            if (w > 90) w = 90;

            if (w < 25)
            {
                minWeight = 0;
                maxWeight = 24.9m;
                categoryName = "до 25 кг";
            }
            else
            {
                int index = (int)Math.Floor((w - 25) / 3);
                minWeight = 25 + index * 3;
                maxWeight = minWeight + 2.9m;
                if (maxWeight > 90) maxWeight = 90;
                categoryName = $"{minWeight:0.0}-{maxWeight:0.0} кг";
            }

            using (var cmd = new SqlCommand("SELECT WeightCatID FROM WeightCategories WHERE CategoryName = @N AND Gender = @G", conn, tr))
            {
                cmd.Parameters.Add("@N", SqlDbType.NVarChar, 50).Value = categoryName;
                cmd.Parameters.Add("@G", SqlDbType.Char, 1).Value = gender;
                var res = cmd.ExecuteScalar();
                if (res != null) return (int)res;
            }

            using (var cmd = new SqlCommand(
                "INSERT INTO WeightCategories (CategoryName, MinWeight, MaxWeight, Gender) OUTPUT INSERTED.WeightCatID VALUES (@N, @MinW, @MaxW, @G)",
                conn, tr))
            {
                cmd.Parameters.Add("@N", SqlDbType.NVarChar, 50).Value = categoryName;

                var minParam = cmd.Parameters.Add("@MinW", SqlDbType.Decimal);
                minParam.Precision = 4;
                minParam.Scale = 1;
                minParam.Value = minWeight;

                var maxParam = cmd.Parameters.Add("@MaxW", SqlDbType.Decimal);
                maxParam.Precision = 4;
                maxParam.Scale = 1;
                maxParam.Value = maxWeight;

                cmd.Parameters.Add("@G", SqlDbType.Char, 1).Value = gender;
                return (int)cmd.ExecuteScalar();
            }
        }

        private int CreateCompetitionGroup(SqlConnection conn, SqlTransaction tr, int ageId, int weightId, string gender, int tatamiId)
        {
            using (var cmd = new SqlCommand(
                "INSERT INTO CompetitionGroups (AgeCatID, WeightCatID, Gender, TatamiID, GroupStatus) OUTPUT INSERTED.GroupID VALUES (@A, @W, @G, @T, 'Active')",
                conn, tr))
            {
                cmd.Parameters.AddWithValue("@A", ageId);
                cmd.Parameters.AddWithValue("@W", weightId);
                cmd.Parameters.AddWithValue("@G", gender);
                cmd.Parameters.AddWithValue("@T", tatamiId);
                return (int)cmd.ExecuteScalar();
            }
        }

        private void UpdateParticipantGroup(SqlConnection conn, SqlTransaction tr, int pid, int gid)
        {
            using (var cmd = new SqlCommand("UPDATE Participants SET GroupID = @G WHERE ParticipantID = @P", conn, tr))
            {
                cmd.Parameters.AddWithValue("@G", gid);
                cmd.Parameters.AddWithValue("@P", pid);
                cmd.ExecuteNonQuery();
            }
        }

        private void ButtonPrint_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new PrintDialog();

            if (dlg.ShowDialog() == true)
            {
                dlg.PrintVisual(GroupsDataGrid, "Список встреч");
            }
        }
        private void ButtonBack_Click(object sender, RoutedEventArgs e) { new RegistrationWindow().Show(); this.Close(); }
        private void ButtonNext_Click(object sender, RoutedEventArgs e) { new MeetingWindow().Show(); this.Close(); }
        private void CloseButton_Click(object sender, RoutedEventArgs e) => this.Close();
    }
}