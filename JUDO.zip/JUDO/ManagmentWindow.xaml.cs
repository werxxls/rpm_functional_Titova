﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JUDO
{
    /// <summary>
    /// Логика взаимодействия для ManagmentWindow.xaml
    /// </summary>
    public partial class ManagmentWindow : Window
    {
        public ManagmentWindow()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e) { new CompetitionsWindow().Show(); this.Close(); }
        private void ButtonNext_Click(object sender, RoutedEventArgs e) { new DiplomWindow().Show(); this.Close(); }

    }
}
