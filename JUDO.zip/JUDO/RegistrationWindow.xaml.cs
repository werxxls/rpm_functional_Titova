﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace JUDO
{
    public partial class RegistrationWindow : Window
    {
        private readonly string _conn = ConfigurationManager.ConnectionStrings["JUDODbConn"].ConnectionString;
        private readonly List<Participant> _participants = new List<Participant>();

        public RegistrationWindow()
        {
            InitializeComponent();
            Loaded += RegistrationWindow_Loaded;
        }

        private void RegistrationWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadParticipants();
        }

        private void LoadParticipants(string search = "", string sort = "")
        {
            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();

                    string sql = @"
                        SELECT p.ParticipantID, p.Surname, p.Name, p.Gender, p.BirthDate, p.Weight, p.Location, ISNULL(c.ClubName, '') AS ClubName
                        FROM Participants p
                        LEFT JOIN ParticipantClubs pc ON p.ParticipantID = pc.ParticipantID
                        LEFT JOIN Clubs c ON pc.ClubID = c.ClubID
                        WHERE p.IsDisqualified = 0";

                    if (!string.IsNullOrEmpty(search))
                        sql += " AND (p.Surname LIKE @S OR p.Name LIKE @S OR p.Location LIKE @S)";

                    if (!string.IsNullOrEmpty(sort))
                        sql += $" ORDER BY {sort}";
                    else
                        sql += " ORDER BY p.Surname";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        if (!string.IsNullOrEmpty(search))
                            cmd.Parameters.AddWithValue("@S", $"%{search}%");

                        using (var reader = cmd.ExecuteReader())
                        {
                            _participants.Clear();
                            while (reader.Read())
                            {
                                decimal? weight = reader.IsDBNull(5) ? (decimal?)null : reader.GetDecimal(5);

                                _participants.Add(new Participant
                                {
                                    ParticipantID = reader.GetInt32(0),
                                    Surname = reader.GetString(1),
                                    Name = reader.GetString(2),
                                    Gender = reader.GetString(3),
                                    BirthDate = reader.GetDateTime(4),
                                    Weight = weight,
                                    Location = reader.GetString(6),
                                    ClubName = reader.IsDBNull(7) ? "" : reader.GetString(7)
                                });
                            }
                        }
                    }
                }
                ParticipantsDataGrid.ItemsSource = null;
                ParticipantsDataGrid.ItemsSource = _participants;
            }
            catch (Exception)
            {
            }
        }

        private void SearchTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (((TextBox)sender).Text == "Поиск...") ((TextBox)sender).Text = "";
        }

        private void SearchTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(((TextBox)sender).Text)) ((TextBox)sender).Text = "Поиск...";
        }

        private void ParticipantsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e) { }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => this.Close();

        private void ButtonNext_Click(object sender, RoutedEventArgs e)
        {
            new GroupWindow().Show();
            this.Close();
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            new NavigationWindow().Show();
            this.Close();
        }

        private void ButtonSearchSort_Click(object sender, RoutedEventArgs e)
        {
            string search = SearchTextBox.Text.Trim();
            if (search == "Поиск...") search = "";
            string sort = (SortComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "";
            LoadParticipants(search, sort);
        }

        private void ButtonImport_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "CSV файлы|*.csv", Title = "Импорт участников" };
            if (dlg.ShowDialog() != true) return;

            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    var lines = System.IO.File.ReadAllLines(dlg.FileName);

                    for (int i = 1; i < lines.Length; i++)
                    {
                        var values = lines[i].Split(';');
                        if (values.Length < 5) continue;

                        string sql = @"INSERT INTO Participants (Surname, Name, Gender, BirthDate, Location, Weight, IsDisqualified) 
                                       VALUES (@S, @N, @G, @B, @L, @W, 0)";

                        using (var cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@S", values[0].Trim());
                            cmd.Parameters.AddWithValue("@N", values[1].Trim());
                            cmd.Parameters.AddWithValue("@G", values[2].Trim().ToLower() == "м" || values[2].Trim().ToLower() == "m" ? "m" : "f");
                            cmd.Parameters.AddWithValue("@B", DateTime.Parse(values[3].Trim()));
                            cmd.Parameters.AddWithValue("@L", values[4].Trim());

                            if (values.Length > 5 && !string.IsNullOrWhiteSpace(values[5]))
                                cmd.Parameters.AddWithValue("@W", decimal.Parse(values[5].Trim()));
                            else
                                cmd.Parameters.AddWithValue("@W", DBNull.Value);

                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                LoadParticipants();
            }
            catch (Exception)
            {
            }
        }

        private void ButtonFinishRegistration_Click(object sender, RoutedEventArgs e)
        {
            new GroupWindow().Show();
            this.Close();
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new EditParticipantDialog();
            if (dialog.ShowDialog() == true)
            {
                LoadParticipants();
            }
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (ParticipantsDataGrid.SelectedItem is Participant selected)
            {
                try
                {
                    using (var conn = new SqlConnection(_conn))
                    {
                        conn.Open();
                        string sql = "UPDATE Participants SET IsDisqualified = 1 WHERE ParticipantID = @ID";
                        using (var cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@ID", selected.ParticipantID);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    LoadParticipants();
                }
                catch (Exception)
                {
                }
            }
        }

        private void ButtonEdit_Click(object sender, RoutedEventArgs e)
        {
            if (ParticipantsDataGrid.SelectedItem is Participant selected)
            {
                var dialog = new EditParticipantDialog(selected);
                if (dialog.ShowDialog() == true)
                {
                    LoadParticipants();
                }
            }
        }
    }
}