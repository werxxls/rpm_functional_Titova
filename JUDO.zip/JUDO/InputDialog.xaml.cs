﻿using System.Windows;

namespace JUDO
{
    public partial class InputDialog : Window
    {
        public string Result { get; private set; }

        public InputDialog(string title, string message, bool isPassword = false)
        {
            InitializeComponent();
            LblTitle.Text = title;
            LblMessage.Text = message;
            Owner = Application.Current.MainWindow;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            if (isPassword)
            {
                TxtInput.Visibility = Visibility.Collapsed;
                PwdInput.Visibility = Visibility.Visible;
                PwdInput.Focus();
            }
            else
            {
                TxtInput.Visibility = Visibility.Visible;
                PwdInput.Visibility = Visibility.Collapsed;
                TxtInput.Focus();
            }
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            Result = PwdInput.Visibility == Visibility.Visible
                ? PwdInput.Password
                : TxtInput.Text;
            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        public static string ShowDialogStatic(Window owner, string title, string message, bool isPassword = false)
        {
            var dialog = new InputDialog(title, message, isPassword) { Owner = owner };
            return dialog.ShowDialog() == true ? dialog.Result : null;
        }
    }
}