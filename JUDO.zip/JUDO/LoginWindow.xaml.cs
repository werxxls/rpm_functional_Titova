﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace JUDO
{
    public partial class LoginWindow : Window
    {
        private readonly string _connString =
            System.Configuration.ConfigurationManager
                .ConnectionStrings["JUDODbConn"]?.ConnectionString
            ?? "Server=localhost;Database=JUDO;Trusted_Connection=True;";

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = TextBoxLogin.Text.Trim();
            string password = PasswordBoxLogin.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                return;
            }

            try
            {
                if (AuthenticateUser(login, password))
                {
                    new NavigationWindow().Show();
                    this.Close();
                }
                else
                {
                    PasswordBoxLogin.Clear();
                    PasswordBoxLogin.Focus();
                }
            }
            catch (Exception)
            {
            }
        }

        private bool AuthenticateUser(string login, string password)
        {
            using (var conn = new SqlConnection(_connString))
            {
                conn.Open();
                string sql = "SELECT COUNT(*) FROM Users WHERE Login = @Login AND Password = @Password";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@Password", password);
                    return (int)cmd.ExecuteScalar() > 0;
                }
            }
        }

        private void ButtonChangePassword_Click(object sender, RoutedEventArgs e)
        {
            string login = InputDialog.ShowDialogStatic(this, "Смена пароля", "Введите ваш логин:");
            if (string.IsNullOrWhiteSpace(login)) return;

            string oldPassword = InputDialog.ShowDialogStatic(this, "Смена пароля", "Введите текущий пароль:", true);
            if (string.IsNullOrWhiteSpace(oldPassword)) return;

            if (!AuthenticateUser(login, oldPassword))
            {
                return;
            }

            string newPassword = InputDialog.ShowDialogStatic(this, "Смена пароля", "Введите новый пароль:", true);
            if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 4)
            {
                return;
            }

            string confirm = InputDialog.ShowDialogStatic(this, "Смена пароля", "Подтвердите новый пароль:", true);
            if (newPassword != confirm)
            {
                return;
            }

            try
            {
                using (var conn = new SqlConnection(_connString))
                {
                    conn.Open();
                    string sql = "UPDATE Users SET Password = @NewPassword WHERE Login = @Login";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@NewPassword", newPassword);
                        cmd.Parameters.AddWithValue("@Login", login);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private void ButtonForgotPassword_Click(object sender, RoutedEventArgs e)
        {
            string login = InputDialog.ShowDialogStatic(this, "Восстановление пароля", "Введите ваш логин:");
            if (string.IsNullOrWhiteSpace(login)) return;

            try
            {
                using (var conn = new SqlConnection(_connString))
                {
                    conn.Open();

                    string sql = "SELECT Password FROM Users WHERE Login = @Login";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@Login", login.Trim());

                        var result = cmd.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            string password = result.ToString();
                            MessageBox.Show(
                                $"Ваш пароль: {password}\n\nНе сообщайте его никому!",
                                "Ваш пароль",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private void ButtonLoginGuest_Click(object sender, RoutedEventArgs e)
        {
            new CompetitionsWindow().Show();
            this.Close();
        }
    }
}