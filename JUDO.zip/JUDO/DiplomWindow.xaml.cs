﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace JUDO
{
    public partial class DiplomWindow : Window
    {
        private readonly string _conn = ConfigurationManager.ConnectionStrings["JUDODbConn"].ConnectionString;

        public DiplomWindow()
        {
            InitializeComponent();
        }

        
        private void BtnGenerate_Click(object sender, RoutedEventArgs e) => MessageBox.Show("Диплом сохранён", "Успех");
        private void BtnPrint_Click(object sender, RoutedEventArgs e) => MessageBox.Show("Печать диплома", "Информация");
        private void BtnExport_Click(object sender, RoutedEventArgs e) => MessageBox.Show("Экспорт в PDF", "Информация");
        private void CloseButton_Click(object sender, RoutedEventArgs e) => this.Close();
    }
}