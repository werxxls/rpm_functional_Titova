﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace JUDO
{
    public partial class EditParticipantDialog : Window
    {
        private readonly string _conn = ConfigurationManager.ConnectionStrings["JUDODbConn"].ConnectionString;
        private readonly Participant _participant;
        private readonly bool _isEdit;

        public EditParticipantDialog() : this(null) { }

        public EditParticipantDialog(Participant participant)
        {
            InitializeComponent();
            _participant = participant ?? new Participant();
            _isEdit = participant != null;
            LblTitle.Text = _isEdit ? "Редактирование участника" : "Добавление участника";
            LoadData();
            LoadClubs();
        }

        private void LoadData()
        {
            if (_participant.ParticipantID > 0)
            {
                TxtSurname.Text = _participant.Surname;
                TxtName.Text = _participant.Name;
                DpBirthDate.SelectedDate = _participant.BirthDate;
                CmbGender.SelectedIndex = _participant.Gender == "m" ? 0 : 1;
                TxtWeight.Text = _participant.Weight?.ToString();
                TxtLocation.Text = _participant.Location;
                CmbClub.Text = _participant.ClubName;
            }
            else
            {
                CmbGender.SelectedIndex = 0;
            }
        }

        private void LoadClubs()
        {
            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("SELECT ClubName FROM Clubs ORDER BY ClubName", conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read()) CmbClub.Items.Add(reader.GetString(0));
                    }
                }
            }
            catch { }
        }

        private int GetOrCreateClubId(SqlConnection conn, SqlTransaction tr, string clubName)
        {
            if (string.IsNullOrWhiteSpace(clubName)) return 0;

            using (var cmd = new SqlCommand("SELECT ClubID FROM Clubs WHERE ClubName = @Name", conn, tr))
            {
                cmd.Parameters.AddWithValue("@Name", clubName);
                var result = cmd.ExecuteScalar();
                if (result != null) return (int)result;
            }

            using (var cmd = new SqlCommand("INSERT INTO Clubs (ClubName) OUTPUT INSERTED.ClubID VALUES (@Name)", conn, tr))
            {
                cmd.Parameters.AddWithValue("@Name", clubName);
                return (int)cmd.ExecuteScalar();
            }
        }

        private void SaveClubRelation(SqlConnection conn, SqlTransaction tr, int participantId, string clubName)
        {
            using (var cmd = new SqlCommand("DELETE FROM ParticipantClubs WHERE ParticipantID = @PID", conn, tr))
            {
                cmd.Parameters.AddWithValue("@PID", participantId);
                cmd.ExecuteNonQuery();
            }

            if (!string.IsNullOrWhiteSpace(clubName))
            {
                int clubId = GetOrCreateClubId(conn, tr, clubName);
                if (clubId > 0)
                {
                    using (var cmd = new SqlCommand("INSERT INTO ParticipantClubs (ParticipantID, ClubID) VALUES (@PID, @CID)", conn, tr))
                    {
                        cmd.Parameters.AddWithValue("@PID", participantId);
                        cmd.Parameters.AddWithValue("@CID", clubId);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtSurname.Text) || !DpBirthDate.SelectedDate.HasValue)
            {
                MessageBox.Show("Заполните обязательные поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _participant.Surname = TxtSurname.Text.Trim();
            _participant.Name = TxtName.Text.Trim();
            _participant.BirthDate = DpBirthDate.SelectedDate.Value;
            _participant.Gender = CmbGender.SelectedIndex == 0 ? "m" : "f";
            _participant.Weight = decimal.TryParse(TxtWeight.Text, out var w) ? w : (decimal?)null;
            _participant.Location = TxtLocation.Text.Trim();
            _participant.ClubName = CmbClub.Text.Trim();

            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    using (var tr = conn.BeginTransaction())
                    {
                        if (_isEdit)
                        {
                            string sql = "UPDATE Participants SET Surname=@S, Name=@N, Gender=@G, BirthDate=@B, Weight=@W, Location=@L WHERE ParticipantID=@ID";
                            using (var cmd = new SqlCommand(sql, conn, tr))
                            {
                                cmd.Parameters.AddWithValue("@S", _participant.Surname);
                                cmd.Parameters.AddWithValue("@N", _participant.Name);
                                cmd.Parameters.AddWithValue("@G", _participant.Gender);
                                cmd.Parameters.AddWithValue("@B", _participant.BirthDate);
                                cmd.Parameters.AddWithValue("@W", (object)_participant.Weight ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@L", _participant.Location);
                                cmd.Parameters.AddWithValue("@ID", _participant.ParticipantID);
                                cmd.ExecuteNonQuery();
                            }
                            SaveClubRelation(conn, tr, _participant.ParticipantID, _participant.ClubName);
                        }
                        else
                        {
                            string sql = "INSERT INTO Participants (Surname, Name, Gender, BirthDate, Weight, Location, IsDisqualified) OUTPUT INSERTED.ParticipantID VALUES (@S,@N,@G,@B,@W,@L,0)";
                            using (var cmd = new SqlCommand(sql, conn, tr))
                            {
                                cmd.Parameters.AddWithValue("@S", _participant.Surname);
                                cmd.Parameters.AddWithValue("@N", _participant.Name);
                                cmd.Parameters.AddWithValue("@G", _participant.Gender);
                                cmd.Parameters.AddWithValue("@B", _participant.BirthDate);
                                cmd.Parameters.AddWithValue("@W", (object)_participant.Weight ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@L", _participant.Location);
                                _participant.ParticipantID = (int)cmd.ExecuteScalar();
                            }
                            if (_participant.ParticipantID > 0)
                            {
                                SaveClubRelation(conn, tr, _participant.ParticipantID, _participant.ClubName);
                            }
                        }
                        tr.Commit();
                    }
                }
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }
    }
}