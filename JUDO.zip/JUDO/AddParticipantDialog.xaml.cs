﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace JUDO
{
    public partial class AddParticipantDialog : Window
    {
        private readonly string _conn = ConfigurationManager.ConnectionStrings["JUDODbConn"].ConnectionString;

        public AddParticipantDialog()
        {
            InitializeComponent();
            Loaded += AddParticipantDialog_Loaded;
        }

        private void AddParticipantDialog_Loaded(object sender, RoutedEventArgs e)
        {
            LoadClubs();
        }

        private void LoadClubs()
        {
            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("SELECT ClubName FROM Clubs ORDER BY ClubName", conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ClubComboBox.Items.Add(reader.GetString(0));
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ButtonAddS_Click(object sender, RoutedEventArgs e)
        {
            string fullName = FullNameTextBox.Text.Trim();
            if (string.IsNullOrEmpty(fullName)) return;

            string[] nameParts = fullName.Split(new[] { ' ' }, 2, StringSplitOptions.RemoveEmptyEntries);
            string surname = nameParts.Length > 0 ? nameParts[0] : "";
            string name = nameParts.Length > 1 ? nameParts[1] : "";

            DateTime birthDate = BirthDatePicker.SelectedDate ?? DateTime.Today;

            if (!decimal.TryParse(WeightTextBox.Text.Trim(), out decimal weight)) return;

            string gender = ((ComboBoxItem)GenderComboBox.SelectedItem)?.Content?.ToString() == "Женский" ? "f" : "m";

            string city = CityTextBox.Text.Trim();
            string clubName = ClubComboBox.Text.Trim();

            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    using (var tr = conn.BeginTransaction())
                    {
                        int clubId = 0;
                        if (!string.IsNullOrEmpty(clubName))
                        {
                            using (var cmd = new SqlCommand("SELECT ClubID FROM Clubs WHERE ClubName = @Name", conn, tr))
                            {
                                cmd.Parameters.AddWithValue("@Name", clubName);
                                var result = cmd.ExecuteScalar();
                                if (result != null)
                                {
                                    clubId = (int)result;
                                }
                                else
                                {
                                    using (var insertCmd = new SqlCommand("INSERT INTO Clubs (ClubName) OUTPUT INSERTED.ClubID VALUES (@Name)", conn, tr))
                                    {
                                        insertCmd.Parameters.AddWithValue("@Name", clubName);
                                        clubId = (int)insertCmd.ExecuteScalar();
                                    }
                                }
                            }
                        }

                        int participantId;
                        using (var cmd = new SqlCommand(
                            "INSERT INTO Participants (Surname, Name, Gender, BirthDate, Weight, Location, IsDisqualified) OUTPUT INSERTED.ParticipantID VALUES (@S, @N, @G, @B, @W, @L, 0)",
                            conn, tr))
                        {
                            cmd.Parameters.AddWithValue("@S", surname);
                            cmd.Parameters.AddWithValue("@N", name);
                            cmd.Parameters.AddWithValue("@G", gender);
                            cmd.Parameters.AddWithValue("@B", birthDate);
                            cmd.Parameters.AddWithValue("@W", weight);
                            cmd.Parameters.AddWithValue("@L", city);
                            participantId = (int)cmd.ExecuteScalar();
                        }

                        if (clubId > 0)
                        {
                            using (var cmd = new SqlCommand(
                                "INSERT INTO ParticipantClubs (ParticipantID, ClubID) VALUES (@P, @C)",
                                conn, tr))
                            {
                                cmd.Parameters.AddWithValue("@P", participantId);
                                cmd.Parameters.AddWithValue("@C", clubId);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        tr.Commit();
                    }
                }
                DialogResult = true;
                Close();
            }
            catch (Exception)
            {
            }
        }
    }
}