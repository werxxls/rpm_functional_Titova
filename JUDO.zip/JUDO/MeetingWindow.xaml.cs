﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace JUDO
{
    public partial class MeetingWindow : Window
    {
        private readonly string _conn = ConfigurationManager.ConnectionStrings["JUDODbConn"].ConnectionString;
        private readonly List<MatchItem> _matches = new List<MatchItem>();
        private bool _showSingleParticipantOnly = false;

        public MeetingWindow()
        {
            InitializeComponent();
            Loaded += MeetingWindow_Loaded;
        }

        private void MeetingWindow_Loaded(object sender, RoutedEventArgs e) => LoadData();

        private void LoadData(string search = "", string sort = "")
        {
            try
            {
                using (var conn = new SqlConnection(_conn))
                {
                    conn.Open();

                    string participantCountSubquery = @"
                        (SELECT COUNT(*) 
                         FROM Participants p 
                         WHERE p.GroupID = cg.GroupID AND p.IsDisqualified = 0)";

                    string sql = $@"
                SELECT 
                    ISNULL(m.MatchID, 0) AS MatchID,
                    cg.GroupID,
                    ac.CategoryName + ' / ' + wc.CategoryName AS GroupName,
                    {participantCountSubquery} AS ParticipantCount,
                    (SELECT TOP 1 p.Surname + ' ' + p.Name 
                     FROM Participants p 
                     WHERE p.GroupID = cg.GroupID AND p.IsDisqualified = 0) AS SingleParticipant,
                    ISNULL((SELECT p.Surname + ' ' + p.Name 
                     FROM MatchParticipants mp 
                     JOIN Participants p ON mp.ParticipantID = p.ParticipantID 
                     WHERE mp.MatchID = m.MatchID AND mp.BeltColor = 'W'), '-') AS WhiteParticipant,
                    ISNULL((SELECT p.Surname + ' ' + p.Name 
                     FROM MatchParticipants mp 
                     JOIN Participants p ON mp.ParticipantID = p.ParticipantID 
                     WHERE mp.MatchID = m.MatchID AND mp.BeltColor = 'R'), '-') AS RedParticipant,
                    t.TatamiNumber,
                    ISNULL(m.MatchStatus, 'Ожидается') AS MatchStatus,
                    m.SequenceNumber
                FROM CompetitionGroups cg
                JOIN AgeCategories ac ON cg.AgeCatID = ac.AgeCatID
                JOIN WeightCategories wc ON cg.WeightCatID = wc.WeightCatID
                LEFT JOIN Tatami t ON cg.TatamiID = t.TatamiID
                LEFT JOIN Matches m ON m.GroupID = cg.GroupID
                WHERE cg.GroupStatus = 'Active'";

                    if (_showSingleParticipantOnly)
                        sql += $" AND {participantCountSubquery} = 1";

                    if (!string.IsNullOrEmpty(search))
                        sql += @" AND (
                            EXISTS (SELECT 1 FROM Participants p WHERE p.GroupID = cg.GroupID AND (p.Surname LIKE @S OR p.Name LIKE @S))
                            OR wc.CategoryName LIKE @S
                            OR ac.CategoryName LIKE @S
                        )";

                    if (!string.IsNullOrEmpty(sort))
                        sql += $" ORDER BY {sort}";
                    else
                        sql += @" ORDER BY 
                            ac.AgeCatID ASC,
                            wc.WeightCatID ASC, 
                            cg.Gender ASC,
                            cg.GroupID ASC,
                            CASE WHEN m.SequenceNumber IS NULL THEN 0 ELSE 1 END ASC,
                            ISNULL(m.SequenceNumber, 0) ASC,
                            ISNULL(m.MatchID, 0) ASC";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        if (!string.IsNullOrEmpty(search))
                            cmd.Parameters.AddWithValue("@S", $"%{search}%");

                        using (var reader = cmd.ExecuteReader())
                        {
                            _matches.Clear();
                            while (reader.Read())
                            {
                                int matchID = reader.GetInt32(0);
                                int participantCount = reader.IsDBNull(3) ? 0 : reader.GetInt32(3);
                                string singleParticipant = reader.IsDBNull(4) ? "" : reader.GetString(4);
                                string white = reader.IsDBNull(5) ? "-" : reader.GetString(5);
                                string red = reader.IsDBNull(6) ? "-" : reader.GetString(6);
                                int? tat = reader.IsDBNull(7) ? (int?)null : reader.GetInt32(7);
                                string status = reader.IsDBNull(8) ? "Ожидается" : reader.GetString(8);

                                string groupName = reader.GetString(2);

                                if (participantCount == 1 && matchID == 0 && !string.IsNullOrEmpty(singleParticipant))
                                {
                                    _matches.Add(new MatchItem
                                    {
                                        MatchID = 0,
                                        GroupName = $"{groupName} (1 участник)",
                                        ParticipantWhite = $"{singleParticipant}",
                                        ParticipantRed = "—",
                                        TatamiNumber = tat,
                                        Status = "Без соперника"
                                    });
                                }
                                else if (matchID > 0)
                                {
                                    _matches.Add(new MatchItem
                                    {
                                        MatchID = matchID,
                                        GroupName = groupName,
                                        ParticipantWhite = white,
                                        ParticipantRed = red,
                                        TatamiNumber = tat,
                                        Status = status
                                    });
                                }
                            }
                        }
                    }
                }
                MeetingsDataGrid.ItemsSource = null;
                MeetingsDataGrid.ItemsSource = _matches;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ButtonSearch_Click(object sender, RoutedEventArgs e)
        {
            string search = SearchTextBox.Text.Trim();
            if (search == "Поиск...") search = "";
            string sort = (SortComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "";
            LoadData(search, sort);
        }

        private void ButtonShowSingleParticipantMatches_Click(object sender, RoutedEventArgs e)
        {
            _showSingleParticipantOnly = !_showSingleParticipantOnly;
            LoadData();

            string msg = _showSingleParticipantOnly
                ? $"Показаны группы с 1 участником: {_matches.Count}"
                : $"Показаны все встречи: {_matches.Count}";
            MessageBox.Show(msg, "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ButtonPrint_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new PrintDialog();

            if (dlg.ShowDialog() == true)
            {
                dlg.PrintVisual(MeetingsDataGrid, "Список встреч");
            }
        }
        private void ButtonRefresh_Click(object sender, RoutedEventArgs e) { _showSingleParticipantOnly = false; LoadData(); }
        private void ButtonBack_Click(object sender, RoutedEventArgs e) { new GroupWindow().Show(); this.Close(); }
        private void ButtonNext_Click(object sender, RoutedEventArgs e) { new DiplomWindow().Show(); this.Close(); }
        private void CloseButton_Click(object sender, RoutedEventArgs e) => this.Close();

        private void SearchTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (((TextBox)sender).Text == "Поиск..." )
                ((TextBox)sender).Text = "";
        }

        private void SearchTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(((TextBox)sender).Text))
                ((TextBox)sender).Text = "Поиск...";
        }
    }
}